# Deep Learning And Paddle Tutorial

Tutorial for Paddle

it includes
* lesson3  logistic classification with numpy and paddle

features:
* 1
* 2
